package com.lee.suming.activitys;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.lee.suming.R;
import com.lee.suming.fix.FixUtils;

/**
 * Created by lee.
 * Time 2016/12/26 15:58
 */
public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.bt).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent();
                i.setClassName(MainActivity.this, "com.lee.test.TestActivity");
                startActivity(i);
            }
        });
        findViewById(R.id.bt1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FixUtils fixUtils = new FixUtils();
                fixUtils.setFix(MainActivity.this);
            }
        });

    }

}
