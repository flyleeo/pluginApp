package com.lee.suming.activitys;

import android.app.Application;
import android.os.Environment;
import android.util.Log;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.lee.suming.fix.FixUtils;
import com.lee.suming.hook.HookUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import dalvik.system.DexClassLoader;

/**
 * Created by lee.
 * Time 2017/2/8 22:53
 */

public class MyApplication extends Application {
    private static MyApplication myApplication;
    private RequestQueue requestQueue;

    private static MyApplication getInstance() {
        return myApplication;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        /**
         * 构筑
         */
        HookUtils hookUtils = new HookUtils(ProxyActivity.class, this);
        hookUtils.hook();
        try {
            hookUtils.hookSysHandler();
        } catch (Exception e) {
            e.printStackTrace();
        }
        myApplication = this;

    }


    public RequestQueue getRequestQueue() {
        if (requestQueue == null)
            requestQueue = Volley.newRequestQueue(this);
        return requestQueue;
    }

}
