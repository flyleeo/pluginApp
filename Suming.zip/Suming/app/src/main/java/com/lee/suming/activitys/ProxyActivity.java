package com.lee.suming.activitys;

import android.app.Activity;

/**
 * Created by lee.
 * Time 2017/2/14 22:29
 */

public class ProxyActivity extends Activity {
}
