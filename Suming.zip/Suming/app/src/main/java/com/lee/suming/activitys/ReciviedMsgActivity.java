package com.lee.suming.activitys;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.TextView;

import com.lee.basemodel.BaseActivity;
import com.lee.basemodel.anno.BindViews;
import com.lee.basemodel.anno.Click;
import com.lee.basemodel.anno.LayoutView;
import com.lee.basemodel.anno.MsgAction;
import com.lee.suming.R;

/**
 * Created by lee.
 * Time 2017/1/10 10:53
 */

//@LayoutView(R.layout.activity_send_msg)
public class ReciviedMsgActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        TextView tv = new TextView(this);
//        tv.setText("133444");
        setContentView(R.layout.activity_send_msg);
    }
    //    @BindViews(R.id.bt2)
//    TextView bt2;
//    StringBuilder sb = new StringBuilder();
//    @Override
//    protected void afterInitView() {
//        bt2.setText("2323223");
//    }
//    @Click(R.id.bt1)
//    public void click(View view){
//        startActivity(new Intent(this,SendMsgActivity.class));
//    }
//
//    @MsgAction(name = "bbb")
//    public void getActivity(Object object){
//        sb.append(object.toString());
//        bt2.setText(sb.toString());
//    }
}
