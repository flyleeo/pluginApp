package com.lee.suming.fix;

import android.content.Context;
import android.os.Environment;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Array;
import java.lang.reflect.Field;

import dalvik.system.BaseDexClassLoader;
import dalvik.system.DexClassLoader;
import dalvik.system.PathClassLoader;

/**
 * Created by lee.
 * Time 2017/2/18 15:09
 * 热修复原理 .
 * apk加载自己的dex文件需要用PathClassLoader  而加载外部的dex或apk时需要 用到DexClassLoader *
 * 这两个类都继承了 BaseClassLoader.
 * BaseClassLoader中有个变量为DexPathList  DexPathList中有一个dexElements这个是用来存放dex文件一些东西
 * 当初始化activity时  类加载器会调用DexPathList.findClass()方法
 * 这个方法 遍历了dexElements 这个数组 根据二进制加载类名 找到就返回 类的实例化.
 * 如果我们把外部加载的dex放到数组的前面  类加载器只会加载前面的替换正确的activity
 *
 */

public class FixUtils {


    private String path;
    private final static String APP_NAME = "app-debug.apk";

    public void setFix(Context context) {
        File file22 = new File(
                Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "suMing");
        if (!file22.exists()) {
            file22.mkdirs();
        }

        path = file22.getAbsolutePath() + File.separator + APP_NAME;
        File filePath = new File(path);
        if (!filePath.exists()) {
            FileInputStream fileInputStream = null;
            FileOutputStream fileOutputStream = null;
            try {
                String path = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + APP_NAME;
                File file1 = new File(path);
                if (file1.exists()) {
                    fileInputStream = new FileInputStream(file1);
                    fileOutputStream = new FileOutputStream(filePath);
                    byte[] bytes = new byte[1024];
                    while (fileInputStream.read(bytes) != -1) {
                        fileOutputStream.write(bytes);
                    }


                }

                loadApk(context);
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (fileOutputStream != null)
                        fileOutputStream.close();
                    if (fileInputStream != null)
                        fileInputStream.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }


        } else {
            loadApk(context);
        }

    }

    private void loadApk(Context context) {
        try {
            ClassLoader classLoader = context.getClassLoader();
            File fileOpt = context.getDir("opt_dex", Context.MODE_PRIVATE);
            if (!fileOpt.exists()) {
                fileOpt.mkdirs();
            }
            DexClassLoader dexClassLoader = new DexClassLoader(
                    Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + APP_NAME
                    , fileOpt.getAbsolutePath()
                    , null
                    , classLoader);


            PathClassLoader pathClassLoader = (PathClassLoader) classLoader;

            Object dexLoader = getPathList(dexClassLoader);
            Object pathLoader = getPathList(pathClassLoader);

            Object dexObj = getDexElement(dexLoader);
            Object pathObj = getDexElement(pathLoader);

            Object o = combineArray(dexObj, pathObj);
            Object object = getPathList(pathClassLoader);

            setField(object, object.getClass(), "dexElements", o);
            Toast.makeText(context, "加载成功", Toast.LENGTH_SHORT).show();


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 给属性赋值
     * @param object
     * @param clazz
     * @param name
     * @param values
     * @throws Exception
     */
    private static void setField(Object object, Class clazz, String name, Object values) throws Exception {
        Field field = clazz.getDeclaredField(name);
        field.setAccessible(true);
        field.set(object, values);
    }

    private Object getDexElement(Object dexLoader) throws Exception {
        return getField(dexLoader, dexLoader.getClass(), "dexElements");
    }

    private static Object getField(Object object, Class clazz, String name) throws Exception {
        Field pathList1 = clazz.getDeclaredField(name);
        pathList1.setAccessible(true);
        return pathList1.get(object);
    }

    private static Object getPathList(BaseDexClassLoader baseDexClassLoader) throws Exception {

        Class<?> baseLoader = Class.forName("dalvik.system.BaseDexClassLoader");

        return getField(baseDexClassLoader, baseLoader, "pathList");
    }

    private static Object combineArray(Object dexObj, Object pathObj) {
        Class<?> componentType = dexObj.getClass().getComponentType();
        int i = Array.getLength(dexObj);
        int j = i + Array.getLength(pathObj);
        Object result = Array.newInstance(componentType, j);
        for (int k = 0; k < j; ++k) {
            if (k < i) {
                Array.set(result, k, Array.get(dexObj, k));
            } else {
                Array.set(result, k, Array.get(pathObj, k - i));
            }
        }
        return result;
    }


}
