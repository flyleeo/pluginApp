package com.lee.suming.hook;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.util.Log;

import com.lee.suming.activitys.ProxyActivity;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

/**
 * Created by lee.
 * Time 2017/2/14 21:42
 * 勾住IActivityManager的startActivity 方法 将代理的注册activity路径传进去.为了绕过验证manifest中的activity注册
 * <p>
 * 在ActivityThread的Headler中 再将其取出来进行类加载 这样就可以达到未注册activity也能展现.
 */

public class HookUtils {
    private Class<?> proxyClass;
    private Context context;

    public HookUtils(Class clazz, Context context) {
        this.context = context;
        this.proxyClass = clazz;
    }

    public void hook() {
        try {
            //通过反射得到ActivityManagerNative;
            Class clazz = Class.forName("android.app.ActivityManagerNative");
            //得到它的变量gDefault
            Field gDefault = clazz.getDeclaredField("gDefault");
            //设置变量权限可变
            gDefault.setAccessible(true);
            //gDefault 为单例 所以直接可以拿到它的值
            Object value = gDefault.get(null);
            //得到IActivityManager单例实现
            Class<?> singleton = Class.forName("android.util.Singleton");
            Field mInstance = singleton.getDeclaredField("mInstance");
            mInstance.setAccessible(true);
            //IActivityManager实现类  它中调用startActivity方法 并且把将要跳转的Activity 封装到Intent中

            Object o = mInstance.get(value);


            Class<?> aClass = Class.forName("android.app.IActivityManager");
            //用动态代理 将intent参数替换成已注册的acitivity. 并把已替换掉的acitivity当参数跟着一起传递.
            Object o1 = Proxy.newProxyInstance(context.getClassLoader(), new Class[]{aClass}, new MyProxyHandler(o));

            mInstance.set(value, o1);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    class MyProxyHandler implements InvocationHandler {
        private Object mo;

        public MyProxyHandler(Object o) {
            this.mo = o;
        }

        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            //找到这个方法
            if (method.getName().contains("startActivity")) {
                int index = 0;
                Intent intent = null;
                for (int i = 0; i < objects.length; i++) {
                    //找到intent参数 并取出
                    if (objects[i] instanceof Intent) {
                        index = i;
                        intent = (Intent) objects[i];
                        break;

                    }

                }
                //将参数替换 并将被替换的传入intent中
                Intent proxyIntent = new Intent();
                ComponentName componentName = new ComponentName(context, ProxyActivity.class);
                proxyIntent.setComponent(componentName);
                Log.e("oldIntent", intent == null ? "" : intent.getComponent().getClassName());
                proxyIntent.putExtra("oldIntent", intent);

                objects[index] = proxyIntent;

                return method.invoke(mo, objects);
            }
            return method.invoke(mo, objects);
        }
    }

    /**
     * 绕过系统检测 再加载类之前 把原来的activity 替换 代理activity  保证正确的类初始化.
     * @throws Exception
     */
    public void hookSysHandler() throws Exception {

        Class<?> aClass = Class.forName("android.app.ActivityThread");
        Field sCurrentActivityThread = aClass.getDeclaredField("sCurrentActivityThread");
        sCurrentActivityThread.setAccessible(true);
        Object activityThread = sCurrentActivityThread.get(null);
        Field mH = aClass.getDeclaredField("mH");
        mH.setAccessible(true);
        Handler handlerObject = (Handler) mH.get(activityThread);
        Field mCallback = Handler.class.getDeclaredField("mCallback");
        mCallback.setAccessible(true);
        mCallback.set(handlerObject, new HandlerCallBack(handlerObject));
        Log.e("hook", "end");
    }

    class HandlerCallBack implements Handler.Callback {
        Handler handler;

        HandlerCallBack(Handler handler) {
            super();
            this.handler = handler;
        }

        @Override
        public boolean handleMessage(Message message) {
            if (message.what == 100) {
                Object obj = message.obj;
                try {
                    Field intent = obj.getClass().getDeclaredField("intent");
                    intent.setAccessible(true);
                    Intent proxyIntent = (Intent) intent.get(obj);
                    Intent oldIntent = proxyIntent.getParcelableExtra("oldIntent");

                    if (oldIntent != null) {
                        proxyIntent.setComponent(oldIntent.getComponent());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            handler.handleMessage(message);
            return true;
        }
    }
}
