package com.lee.basemodel.msg;

/**
 * Created by lee.
 * Time 2017/1/10 20:05
 */

 interface Add {
    void addObservable(String str, Result result);
}
