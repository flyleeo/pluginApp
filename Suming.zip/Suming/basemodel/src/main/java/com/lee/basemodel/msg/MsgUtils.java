package com.lee.basemodel.msg;

import android.util.Log;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import rx.Observable;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

/**
 * Created by lee.
 * Time 2017/1/8 15:54
 *
 */

public class MsgUtils implements Add {
    private static MsgUtils msgUtils;
    private List<Message> msgList;
    private LinkedList<Message> msgCash;
    private int count;

    private MsgUtils() {
        msgList = new ArrayList<>();
        msgCash = new LinkedList<>();
    }

    public static MsgUtils getInstance() {
        if (msgUtils == null) msgUtils = new MsgUtils();
        return msgUtils;
    }

    public void addObservable(String str, Result result) {
        Message msg = new Message();
        msg.key = str;
        msg.result = result;
        msgList.add(msg);
    }

    boolean b = true;

    public synchronized void sendMsg(Message msg) {
        count++;
        msgCash.addFirst(msg);
        if (b) {
            dealMsg();
            b = false;
        }
    }

    private void dealMsg() {
        if (msgCash.isEmpty()) {
            if(count!=0){
                dealMsg();
                return;
            }
            b = true;
            return;
        }
        Observable.just(msgCash.getLast()).filter(new Func1<Message, Boolean>() {
            @Override
            public Boolean call(Message message) {
                return msgList != null && msgList.size() > 0;
            }
        }).map(new Func1<Message, Message>() {
            @Override
            public Message call(Message msg) {
                Message ms = null;
                for (Message message : msgList) {
                    if (message.key.equals(msg.key)) {
                        message.object = msg.object;
                        ms = message;
                    }
                }
                return ms;
            }
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Action1<Message>() {
                    @Override
                    public void call(Message msg) {
                        if (msg.result == null) {
                            return;
                        }
                        msg.result.getResult(msg.object);
                        msgCash.removeLast();
                        Log.i("out", msg.object.toString());
                        count--;
                        dealMsg();
                    }
                });
    }


    public void removeObservable(String str) {
        for (Message msg : msgList) {
            if (msg.key.equals(str)) {
                msgList.remove(msg);
                break;
            }
        }
    }
}
