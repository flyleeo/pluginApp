package com.lee.basemodel.msg;

/**
 * Created by lee.
 * Time 2017/1/10 21:06
 */

public class ResultImpl implements Result {
    @Override
    public void getResult(Object o) {

    }
}
